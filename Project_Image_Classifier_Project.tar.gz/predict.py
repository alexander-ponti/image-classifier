#!/usr/bin/env python
import argparse
import tensorflow as tf
import tensorflow_hub as hub
import json
import numpy as np
import predictor_utils as utils
from PIL import Image

class FlowerPredictor:
    def __init__(self):
        self.categoryFilename = 'label_map_tfds.json'
        self.categoryNames = None
        self.topK = 5 #default
        
    def valid(self, args):
        isValid = True
        # path-to-image-to-predict
        # model
        # top_k
        # category_names json file
        
        if args.top_k != None and args.top_k > 0:
            self.topK = args.top_k
        else: return False    
        
        inputF = self.categoryFilename
        if args.category_names != None and args.category_names != "":
            inputF = args.category_names
        
        # validate
        try:
            with open(inputF, 'r') as f:
                self.categoryNames = json.load(f)
            self.numCategories = len(self.categoryNames)
        except OSError as e:
            print(f"An exception occured opening file: {e}")
            return False            
       
        if args.path_to_image[0] != None and args.path_to_image[0] != "":
            try:
                with open(args.path_to_image[0], 'r') as f:
                    pass
                self.pathToImage = args.path_to_image[0]
            except OSError as e:
                print(f"An exception occured opening file: {e}")
                return False
   
        if args.saved_model[0] != None and args.saved_model[0] != "":
            try:
                with open(args.saved_model[0], 'r') as f:
                    pass
                self.savedKerasModelFilepath = args.saved_model[0]
            except OSError as e:
                print(f"An exception occured opening file: {e}")
                isValid = False
        return isValid

    def loadModel(self):
        # Load the Keras model
        # Note: use saved model 'alexKerasModel.h5' in place of saved_keras_model_filepath
        # when not training
        self.model = tf.keras.models.load_model(self.savedKerasModelFilepath, custom_objects={'KerasLayer':hub.KerasLayer}) 
        
    def modelSummary(self):    
        self.model.summary()

        
    def predict(self):
        im = Image.open(self.pathToImage)
        test_image = np.asarray(im)
        processed_test_image = utils.process_image(test_image, True)
        probs = self.model.predict(processed_test_image)
        
        p, c = self.getTopK(probs, self.topK)
        #print(f"labels: {c}")
        
        names = self.indexesToLabels(c)
        return p, names

    def getTopK(self, proba, top_k):
        #print(f"prediction: {self.indexToLabel(np.argmax(proba, axis=-1)[0])}")
        prob = proba.flatten().tolist()
        classes = []
        p = []

        for _ in range(0, top_k):
            top = max(prob)
            ind = prob.index(top)
            classes.append(ind)
            p.append(top)
            prob[ind] = -1

        return p, classes
  
    def indexToLabel(self, index):
        return self.categoryNames[str(index)]
 
    def indexesToLabels(self, classes):
        labels = []
        for index in classes:
            labels.append(self.categoryNames[str(index)])
        return labels
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Flower image prediction.', usage='predict.py path-to-image model --top_k [integer] --category_names [json map of labels]')
    parser.add_argument('path_to_image', metavar='1', type=str, nargs=1, \
                        help='path to the image to be predicted')
    parser.add_argument('saved_model', metavar='2', type=str, nargs=1, \
                        help='filename of the saved Keras model')
    parser.add_argument('--top_k', dest='top_k', default=5, type=int, \
                        help='Return the top K most likely classes (default: 5)')
    parser.add_argument('--category_names', dest='category_names', type=str, \
                        help='Path to a JSON file mapping labels to flower names')

    args = parser.parse_args()    
    
    predictor = FlowerPredictor()
    #Validate arguments
    if not predictor.valid(args):
        exit()
    
    predictor.loadModel()
    score, labels = predictor.predict()

    print(f"\nscores: \t{score}")
    print(f"classes:\t{labels}");