import numpy as np
import tensorflow as tf

def process_image(img, predicting=False):
    image_size = 224
    image = tf.cast(img, tf.float32)
    image = tf.image.resize(image, (image_size, image_size))
    image /= 255
    if predicting:
        image = np.expand_dims(image, axis=0)
    else: image = image.numpy()    
    return image

def iteratorToList(it):
    lst = []
    for x in it:
        lst.append(x)
    return lst  # for new line
    
